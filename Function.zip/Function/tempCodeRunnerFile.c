#include<stdio.h>
void sum(int x=10,int y=20)
{
    int z=x+y;
    printf("%d",z);
    return;
}
int main()
{
    int x = 10; 
    int y = 20;
    printf("before :");

    sum();

    printf("after ");

    sum(7,3);
return 0;
}