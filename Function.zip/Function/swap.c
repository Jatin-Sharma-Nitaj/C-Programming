 #include<stdio.h>
 int main()
 {
    int a;
    printf("1st No :");
    scanf("%d",&a);

    int b;
    printf("2st No :");
    scanf("%d",&b);

    a=a+b;
    b=a-b;//swap by using extra variable
    a=a-b;//swap by using math equations
    printf("The value 1st a is : %d\n",a);
    printf("The value of 2nd is : %d",b);
    return 0;
 }