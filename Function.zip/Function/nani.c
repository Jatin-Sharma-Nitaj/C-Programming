#include<stdio.h>
void england()
{
    printf("He IS Englandi\n");
    return;
}
void australia()
{
    printf("he is australiandi\n");
    england();
    return;
}
void india()
{
    printf("he is indiandi\n");
    australia();
    return;
}
int main()
{
    india();
    return 0;
}