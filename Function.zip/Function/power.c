#include<stdio.h>
int main()
{
    int a=pow(90,3);
    printf("%d",a);
    return 0;
}
