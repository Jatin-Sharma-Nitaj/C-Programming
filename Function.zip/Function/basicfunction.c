#include<stdio.h>
void greet()
{
    printf("Lets do it\n");
    printf("gambare\n");
    return;
}
int main(){
    greet();
     greet(); 
     greet();
    return 0;
}