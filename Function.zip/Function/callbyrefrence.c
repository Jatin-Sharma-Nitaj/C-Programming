#include<stdio.h>
void add(int *m)
{
    *m=10+*m;
    return;
}
int main()
{
    int n=10;
    printf("Before n = %d\n",n);
    add(&n);//call by adress or refrence
    printf("After n = %d",n);
}
