#include<stdio.h>
int add(int x,int y);// function declleration
int add(int x, int y)//function defenation
{
   int z;
   z=x+y;
   return z;
}
int main()
{
    int a = add(20,30);// calling add function
    printf("add = %d",a);
}