#include<stdio.h>
int main()
{
    int arr[5];// ={2,4,6,8,0};

    for(int i=0;i<=4;i++)
        scanf("%d",arr[1]);
    



    /*printf("Enter Your NUmber");
    scanf("%d",&arr[0]);
     printf("Enter Your NUmber");
    scanf("%d",&arr[1]);
 printf("Enter Your NUmber");
    scanf("%d",&arr[2]);
 printf("Enter Your NUmber");
    scanf("%d",&arr[3]);
 printf("Enter Your NUmber");
    scanf("%d",&arr[4]);

    printf("%d",arr[3]);/**/


    /*/arr[0]=1;
    arr[1]=2;
    arr[3]=3;

    printf("%d ",arr[3]);
     printf("%d ",arr[0]);
      printf("%d ",arr[1]);/**/
}