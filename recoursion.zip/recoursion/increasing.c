#include<stdio.h>
void incresing(int n)
{
  if (n==0) return;
  printf("%d\n",n);
  incresing(n+1);
  return;
}
int main()
{
    int n;
    printf("Enter Your Number :");
    scanf("%d",&n);
    incresing(n);
    return 0;
}