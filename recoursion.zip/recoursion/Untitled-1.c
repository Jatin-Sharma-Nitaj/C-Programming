#include<stdio.h>
void main() {
 float num1  , num2  ;
Char  op;
printf("Enter the opration: + - * /") ;
scanf("%c", &op) ;
printf("Enter two numbers") ;
scanf("%f%f", &num1  ,&num2) ;
switch(op)  {
case + : printf("%f", num1+num2) ;
              break;
case - : printf("%f",num1-num2) ;
             break;
case * : printf("%f",num1*num2) ;
             break;
case / : 
if ( num2 !=0) 
      printf("%f", num1/num2) ;
else
      printf(" Number can not divide by 0") ;
               break;
default : printf(" invalid oprater") ;
}
}