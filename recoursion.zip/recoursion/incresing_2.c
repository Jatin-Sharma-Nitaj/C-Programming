#include<stdio.h>
int  incresing(int n)
{
    if(n==0) return;//base case
    printf("%d\n",n);
      incresing(n-1);//call
}
int main()
{
    int n;
    printf("Enter Your Number :");
    scanf("%d",&n);
     incresing(n);
    return 0;
}