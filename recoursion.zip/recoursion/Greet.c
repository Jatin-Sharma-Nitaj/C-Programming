#include<stdio.h>
int Greet(int n){
    if(n==0) return ;//base case

    printf("good morning\n");
    Greet(n-1);}  
    
int main()
{
    int n;
    printf("Enter YOur NUMber :");
    scanf("%d",&n);
     Greet(n);
    return 0;
}