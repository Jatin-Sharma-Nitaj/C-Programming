#include<stdio.h>
#include "BUbble_sort.h"
int main(){
    int a,temp,i;

    void Bubble_sort(int *arr,int n){
        for(i=0;i<n-1;i++){
            for (int  j = 0; j < n-i; j++)
            {
                if(arr[j]>arr[j+1]){
                temp   =    arr[j];
                arr[j]     = arr[j+1];
                arr[j+1]   = temp;
                }
            }
            
        }
        
    }
      int arr[5] = {12,34,11,89,45};
      int n = sizeof(arr);

      printf("Aray before sorting : ");
      for(int i = 0; i<n; i++){
        printf("%d",&arr[i]);
      }
      Bubble_sort(arr,n);
      printf("\nArray after sorting is :");
      for (int i = 0; i < n; i++)
      {
        printf("%d",arr[i]);/* code */
      }
      
      
}