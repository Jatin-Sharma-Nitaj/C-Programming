#include<stdio.h>
int main()
{
    int a=3;
    int *x = &a;
    printf("%p",x);// adress of a
     printf("\n%p",&x);//adress of x
     printf("%d",*x);//x ke under ka variable
}