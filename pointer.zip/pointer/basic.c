#include<stdio.h>
int main()
{
    int a=5;
    int b=6;
printf("%p\n",&a);//%p se address print hota h
printf("%p",&b);
}


