#include<stdio.h>
int main()
{
    int a,b,c;
    int *p,*q,*r;

     p=&a;//transfer the adress , so it becomes the value of p
     q=&b;
     r=&c;

    printf("1st no :\n");
    scanf("%d",q);
    
    printf("2nd no :\n");
    scanf("%d",r);


     *p=*q+*r;

    printf("%d",*p);
}