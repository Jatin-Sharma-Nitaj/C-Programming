#include <stdio.h>
void main()
{
    int n;
    printf("Enter No :");
    scanf("%d",n);

    for(int i = 1; i <= n; i++){
        if ( i % 2 == 1){
          for(int j='A'; j<='D'; j++)
          {
            printf("%c",j);
          }printf("\n");

        }
    else
    for(int k=1;k<=i;k++){
        printf("%d",k);

    }printf("\n");

    }

}