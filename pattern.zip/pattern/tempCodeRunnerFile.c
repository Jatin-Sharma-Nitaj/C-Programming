#include <stdio.h>

int main() {
    int n = 4;
    int nsp = n / 2;
    int nst = 1;
    int ml = n / 2 + 1;
    
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= nsp; j++) {
            printf(" ");
        }
        for (int k = 1; k <= nst; k++) {
            printf("*");
        }
        if (i < ml) {
            nsp++;
            nst -= 2;
        } else {
            nsp -= 2;
            nst++;
        }
        printf("\n"); // Add this line to move to the next line after each row.
    }

    return 0; // Add this line to return 0 at the end of the main function.
}
