#include<stdio.h>
int main()
{
    int n=4;
    
    
    int m=6;
    
    for(int i=1; i<=n; i++)
    {
        for(int j=1; j<=m; j++)
        {
            if(i==n)
            printf("*");
            else printf(" ");
        }printf("\n");
    }
    
    
}