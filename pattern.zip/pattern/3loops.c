#include<stdio.h>
int main()
{
    int n=4;
    
    for(int i=1; i<=n; i++)
    {
       for(int j=1; j<=n-i; j++)//this will print all the spaces untill condition hit
       {
        printf(" ");
       }
        for(int k=1; k<=i; k++)// will print all the star like a noraml code
       {
            printf("*");
       }printf("\n");
    }
}