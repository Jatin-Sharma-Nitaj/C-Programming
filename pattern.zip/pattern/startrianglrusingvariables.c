#include<stdio.h>
int main()
{
    int n;
    printf("Enter The Number :");
    scanf("%d",&n);
int i=1;
    int b=n-i;
    int a=1;
    for( i=1; i<=n; i++)
    {
        for(int j=1; j<=b; j++)
        {
            printf(" ");
        }
        b--;
        for(int j=1; j<=a; j++)
        {
            printf("*");
        }a=a+2;
        printf("\n");
    }
    return 0;
}