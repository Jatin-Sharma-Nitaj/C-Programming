#include<stdio.h>
int main()
{
    int n = 4;
    int nsp = n-1;
    for(int i=1; i<=n; i++)
    {
        int a=i-1;
        for(int j=1; j<=nsp; j++)
        {
            printf(" ");
        }nsp--;
        for(int l=1; l<=i; l++)
        {
            printf("%d",l);
        }
        for(int k=1; k<=i-1;  k++)
        {
            printf("%d",a);
            a--;
        }printf("\n");
    }
}