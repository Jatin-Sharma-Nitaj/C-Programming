#include<stdio.h>
int main(

)
{
    int n;
    printf("Enter THe nUmber :");
    scanf("%d",&n);

    

    for(int i=1; i<=n; i++) // outer line -> NUMBERE OF LINES (ROWS)
    {
        for (int j=1; j<=n; j++) //INNER LINE -> NUMBER OF STARES (COLLUM)
      {
        printf("*");
      }
        printf("\n");
    }return 0;        
}