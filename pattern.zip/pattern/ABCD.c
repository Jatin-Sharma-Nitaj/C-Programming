#include<stdio.h>
int main()
{
    int n;
   printf("Enter No :");
    scanf( "%d",&n);

    for(int i=1; i<=n; i++)

    {    int a=1;
          for(int j=1; j<=n; j++)
          {
            printf(" ");
          }a=a+2;;
          
          for(int k=1;k<=i;k++)

        {int b = a+64;
        char ch = (char)b;
          printf("%c ",ch);
        a++;
        }printf("\n");
            
    }
}